﻿using aspnetcoreempty.modal;
using Microsoft.AspNetCore.Mvc;
using aspnetcoreempty.ViewModels;

namespace aspnetcoreempty.controller
{
    public class HomeController :Controller
    {
        public IEmployeeRepository _employeeRepository;
        public HomeController(IEmployeeRepository employeeRepository) {
            _employeeRepository = employeeRepository;
        }

        //public string index() {
        //    return _employeerepository.getemployee(1).email;
        //}

        //ViewBag is a wrapper around View Data
        //creates loosely typed view
        //ViewData uses string keys to store  and retrive data
        //ViewBag dynamically resolves in the runtime
        //No-Compile time type checking and intellisense

        //public ViewResult Details() {
        //    Employee modal = _employeeRepository.GetEmployee(1);
        //    //ViewData["Employee"] = modal;
        //    //ViewBag.Employee = modal;
        //    //ViewBag.Title = "Details of Employee";
        //    return View(modal);
        //} view which binds to a specific type of viewModel is strongly typed view
        public ViewResult Details() {
       HomeDetailsViewModel homeDetailsView = new HomeDetailsViewModel() {
           Employee = _employeeRepository.GetEmployee(1),
           Title="Details of Employee"
           };
           return View(homeDetailsView);
        }
        public ViewResult Details1() {
            HomeAllEmpViewModel1 homeAllEmpViewModel1 = new HomeAllEmpViewModel1() {
               Employee = _employeeRepository.GetAllEmployees(),
               Title = " All the Details of Employee from viewmodels"

           };
           return View( homeAllEmpViewModel1);
        }

        //passing the view(html page name ) directly without mentioning the extensions
        //Relative Path(no need of file extension)
        //Absolute Path(where the file is in diff folder) we need to mention
        //file extensions.
     
        public IActionResult Index() {
            //customizing view discovery
            return View("/MyViews/Test.cshtml");
        }
        public IActionResult Employee () {

            return View();
        }
        public IActionResult AllEmp() {
            var modal = _employeeRepository.GetAllEmployees();
                
            return View(modal);
        }
       
    }
}