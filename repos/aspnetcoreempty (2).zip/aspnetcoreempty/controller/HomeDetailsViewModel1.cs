﻿using aspnetcoreempty.modal;
using System.Collections.Generic;

namespace aspnetcoreempty.controller
{
    internal class HomeDetailsViewModel1
    {
        public IEnumerable<Employee> Employee { get; internal set; }
        public string Title { get; internal set; }
    }
}