﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace aspnetcoreempty.modal
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        public List<Employee> _employee = new List<Employee>();
        public MockEmployeeRepository() {
            _employee.Add(new Employee { id = 1, name = "Avi", age = 22, email = "avi27@gmail.com" });
            _employee.Add(new Employee { id = 2, name = "Hima", age = 22, email = "hima27@gmail.com" });
            _employee.Add(new Employee { id = 3, name = "Shreyas", age = 22, email = "shrey27@gmail.com" });
            _employee.Add(new Employee { id = 4, name = "Prajwal", age = 22, email = "praj@gmail.com" });
        }

        public IEnumerable<Employee> GetAllEmployees() {
            return _employee;
        }

        //IEnumerable<Employee> IEmployeeRepository.GetAllEmployees() {
        //    return _employee;
        //}

        Employee IEmployeeRepository.GetEmployee(int id) {

            return _employee.FirstOrDefault(e => e.id == id);
        }
    }
}
