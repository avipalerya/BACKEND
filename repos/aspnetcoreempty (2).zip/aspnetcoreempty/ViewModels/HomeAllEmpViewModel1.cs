﻿using aspnetcoreempty.modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace aspnetcoreempty.ViewModels
{
    public class HomeAllEmpViewModel1
    {
        
        public IEnumerable<Employee> Employee { get; internal set; }
        public string Title { get; set; }
    }
}
